-- phpMyAdmin SQL Dump
-- version 4.7.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 17, 2017 at 05:11 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.0.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u576593533_daten`
--
CREATE DATABASE IF NOT EXISTS `u576593533_daten` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `u576593533_daten`;

-- --------------------------------------------------------

--
-- Table structure for table `app_list_winapi`
--

CREATE TABLE `app_list_winapi` (
  `app_id` bigint(20) UNSIGNED ZEROFILL NOT NULL,
  `app_key` varchar(250) NOT NULL,
  `owner` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_list_winapi`
--

INSERT INTO `app_list_winapi` (`app_id`, `app_key`, `owner`) VALUES
(00000000000000000019, '64WINQXXMQIR3RD33EO6', NULL),
(00000000000000000020, '64WINV74J7Z5CD0GHOVM', NULL),
(00000000000000000021, '64WINI0XZSUXFHA8ZIK4', NULL),
(00000000000000000022, '64WIN9PSBXKFA8T17R5RB23HV', NULL),
(00000000000000000023, '64WINDF4LKAT3NKNM71FFIQ0V', NULL),
(00000000000000000024, '64WINT0VUZ08D39PBOATT11D4', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `benutzer`
--

CREATE TABLE `benutzer` (
  `id` bigint(20) UNSIGNED ZEROFILL NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(75) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `benutzer`
--

INSERT INTO `benutzer` (`id`, `username`, `email`, `pass`) VALUES
(00000000000000000001, 'lionmanbloodsucker', 'lionmanbloodsucker@gmail.com', '$2y$10$YknHI7nNGSn6.0y9oJb4Fu8BNeulyf04EP/5kTxiUHfLOMAG1O5r.'),
(02215964892300808429, 'test1', 'test1@test1.com', '$2y$10$Ro/.NT.UC0Iery.a0F3wQ.ZMN.3w6dcLhEGA9lHVsJJeOBFtl6eD6'),
(02507142755343729677, 'william', 'williamfendy@yahoo.com', '$2y$10$0/0A0j7bh6rKMKGt9OZfqePodwMFraOce/Z9gf01eTqy8rdSnUlga');

-- --------------------------------------------------------

--
-- Table structure for table `download_record`
--

CREATE TABLE `download_record` (
  `id` varchar(255) NOT NULL,
  `benutzer` bigint(20) UNSIGNED DEFAULT NULL,
  `download_start` bigint(20) UNSIGNED NOT NULL,
  `download_finish` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `download_record`
--

INSERT INTO `download_record` (`id`, `benutzer`, `download_start`, `download_finish`) VALUES
('37I0YS1PO1J2BAFH7ISIGCFEV', NULL, 1487760955, NULL),
('CEPE8ERTK2EIYUVI5U352EV5X', NULL, 1487768066, NULL),
('KANEKAHW1EWXPJ24XWVE9N60X', NULL, 1487767433, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `download_record_files`
--

CREATE TABLE `download_record_files` (
  `download_id` varchar(255) NOT NULL,
  `file_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `download_record_files`
--

INSERT INTO `download_record_files` (`download_id`, `file_id`) VALUES
('37I0YS1PO1J2BAFH7ISIGCFEV', 3663487223875414465),
('KANEKAHW1EWXPJ24XWVE9N60X', 7256785927076775455),
('CEPE8ERTK2EIYUVI5U352EV5X', 3663487223875414465);

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `id` bigint(20) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_directory` tinyint(1) NOT NULL DEFAULT '0',
  `seen_by_all` tinyint(1) NOT NULL DEFAULT '0',
  `download_by_all` tinyint(1) NOT NULL DEFAULT '0',
  `modify_by_all` tinyint(1) NOT NULL DEFAULT '0',
  `owner` bigint(20) UNSIGNED ZEROFILL DEFAULT NULL,
  `parent` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file`
--

INSERT INTO `file` (`id`, `name`, `is_directory`, `seen_by_all`, `download_by_all`, `modify_by_all`, `owner`, `parent`, `date_created`) VALUES
(00000000000000000001, 'Document', 1, 0, 0, 0, NULL, NULL, '2016-12-21 04:03:28'),
(00000000000000000002, 'PDF', 1, 0, 0, 0, NULL, 1, '2016-12-21 04:03:28'),
(03034861654602940125, 'abc', 0, 1, 1, 1, NULL, NULL, '2017-02-18 08:14:36'),
(03663487223875414465, 'test(1)', 0, 1, 1, 1, NULL, NULL, '2017-02-22 10:55:25'),
(07256785927076775455, 'Seraph.exe', 0, 1, 0, 1, NULL, NULL, '2017-02-22 11:44:06');

--
-- Triggers `file`
--
DELIMITER $$
CREATE TRIGGER `trigger_after_delete_file` AFTER DELETE ON `file` FOR EACH ROW INSERT INTO file_change_recorder(id_dir, owner) VALUES(old.parent, old.owner)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trigger_after_insert_file` AFTER INSERT ON `file` FOR EACH ROW INSERT INTO file_change_recorder(id_dir, owner) VALUES(NEW.parent, NEW.owner)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trigger_after_update_file` AFTER UPDATE ON `file` FOR EACH ROW BEGIN
INSERT INTO file_change_recorder(id_dir, owner) VALUES(old.parent, old.owner);
INSERT INTO file_change_recorder(id_dir, owner) VALUES (new.parent, new.owner);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `file_change_recorder`
--

CREATE TABLE `file_change_recorder` (
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_dir` bigint(20) UNSIGNED DEFAULT NULL,
  `owner` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file_change_recorder`
--

INSERT INTO `file_change_recorder` (`waktu`, `id_dir`, `owner`) VALUES
('2017-02-18 08:14:36', NULL, NULL),
('2017-02-22 10:55:25', NULL, NULL),
('2017-02-22 11:44:06', NULL, NULL),
('2017-03-05 10:45:10', NULL, NULL),
('2017-03-05 10:45:10', NULL, NULL),
('2017-03-05 10:45:17', NULL, NULL),
('2017-03-05 10:45:17', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `file_operation_log`
--

CREATE TABLE `file_operation_log` (
  `id_operation` varchar(100) NOT NULL,
  `id_dir` bigint(20) UNSIGNED NOT NULL,
  `owner` bigint(20) UNSIGNED DEFAULT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `file_operation_update_log`
--

CREATE TABLE `file_operation_update_log` (
  `id_operation` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `format` mediumint(8) UNSIGNED NOT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `seen_by_all` tinyint(1) NOT NULL,
  `download_by_all` tinyint(1) NOT NULL,
  `modify_by_all` tinyint(1) NOT NULL,
  `owner` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login_log_winapi`
--

CREATE TABLE `login_log_winapi` (
  `login_id` varchar(255) NOT NULL,
  `benutzer` bigint(20) UNSIGNED NOT NULL,
  `app` bigint(20) UNSIGNED NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_log_winapi`
--

INSERT INTO `login_log_winapi` (`login_id`, `benutzer`, `app`, `waktu`) VALUES
('2MPEYTSN0YZSGMJA3VQW6K9GKKKC', 1, 19, '2017-02-17 06:07:39'),
('8PMI9ZJRAC9JKD2SY6UNZUKFYYBE', 1, 24, '2017-03-05 10:44:34'),
('9BJQKYT98OJGMXZYP8HFFDTRGEF3', 1, 19, '2017-02-15 05:53:38'),
('BGT7FO41RW6SJJKNWC11V9D9JNG0', 1, 20, '2017-02-05 14:55:07'),
('G1X0MHS7PL3OLJK6TQWQJDV4TC0C', 2507142755343729677, 19, '2017-02-04 18:39:49'),
('GJLIIY9S658LOOYNVJQ830X3AJ99', 2215964892300808429, 23, '2017-02-24 07:20:03'),
('GPN9JNPBONE6IL8DWOYRSTA3OO7A', 2507142755343729677, 19, '2017-02-05 12:32:51'),
('IY9ANGT31QVODYFZ6T5RJ8ECXKJA', 1, 19, '2017-02-15 05:48:32');

-- --------------------------------------------------------

--
-- Table structure for table `login_log_winapi_fail`
--

CREATE TABLE `login_log_winapi_fail` (
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `benutzer` bigint(20) UNSIGNED NOT NULL,
  `app` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_log_winapi_fail`
--

INSERT INTO `login_log_winapi_fail` (`waktu`, `benutzer`, `app`) VALUES
('2017-02-24 07:19:52', 2215964892300808429, 23);

-- --------------------------------------------------------

--
-- Table structure for table `privilege_benutzer`
--

CREATE TABLE `privilege_benutzer` (
  `benutzer` bigint(20) UNSIGNED NOT NULL,
  `privilege_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `privilege_benutzer_on_object`
--

CREATE TABLE `privilege_benutzer_on_object` (
  `benutzer` bigint(20) UNSIGNED NOT NULL,
  `file_id` bigint(20) UNSIGNED NOT NULL,
  `privilege_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `privilege_group`
--

CREATE TABLE `privilege_group` (
  `privilege_group_id` int(10) UNSIGNED ZEROFILL NOT NULL,
  `group_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `privilege_group`
--

INSERT INTO `privilege_group` (`privilege_group_id`, `group_name`) VALUES
(0000000001, 'Super Admin'),
(0000000002, 'Admin'),
(0000000003, 'Member');

-- --------------------------------------------------------

--
-- Table structure for table `privilege_group_member`
--

CREATE TABLE `privilege_group_member` (
  `group_id` int(10) UNSIGNED NOT NULL,
  `benutzer` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `privilege_group_member`
--

INSERT INTO `privilege_group_member` (`group_id`, `benutzer`) VALUES
(1, 1),
(3, 2215964892300808429),
(3, 2507142755343729677);

-- --------------------------------------------------------

--
-- Table structure for table `privilege_group_privilege`
--

CREATE TABLE `privilege_group_privilege` (
  `privilege_group_id` int(10) UNSIGNED NOT NULL,
  `privilege_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recyle_bin`
--

CREATE TABLE `recyle_bin` (
  `id` bigint(20) UNSIGNED ZEROFILL NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `is_directory` tinyint(1) NOT NULL DEFAULT '0',
  `file_owner` bigint(20) UNSIGNED DEFAULT NULL,
  `parent` bigint(20) UNSIGNED DEFAULT NULL,
  `parent_undeleted` bigint(20) UNSIGNED DEFAULT NULL,
  `date_deleted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `original` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recyle_bin`
--

INSERT INTO `recyle_bin` (`id`, `file_name`, `is_directory`, `file_owner`, `parent`, `parent_undeleted`, `date_deleted`, `original`) VALUES
(01932958882851242272, 'db(1).sql', 0, 1, NULL, NULL, '2017-02-03 15:54:18', 1),
(05034956508883120210, 'db.sql', 0, 1, NULL, NULL, '2017-02-03 13:29:49', 1);

-- --------------------------------------------------------

--
-- Table structure for table `seraph_privilege`
--

CREATE TABLE `seraph_privilege` (
  `privilege_id` int(10) UNSIGNED ZEROFILL NOT NULL,
  `privilege` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seraph_privilege`
--

INSERT INTO `seraph_privilege` (`privilege_id`, `privilege`) VALUES
(0000000001, 'login'),
(0000000002, 'Login as Admin'),
(0000000003, 'Download Any File'),
(0000000004, 'Modify Any File'),
(0000000005, 'Delete Any File'),
(0000000006, 'Delete Member'),
(0000000007, 'Delete Admin'),
(0000000008, 'Join Group'),
(0000000009, 'Remove Member From Group'),
(0000000010, 'BlackList Member from Group'),
(0000000011, 'Kick Member From Group'),
(0000000012, 'Delete Group'),
(0000000013, 'Delete Any Group');

-- --------------------------------------------------------

--
-- Table structure for table `seraph_privilege_on_object`
--

CREATE TABLE `seraph_privilege_on_object` (
  `privilege_id` int(10) UNSIGNED NOT NULL,
  `privilage_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seraph_privilege_on_object`
--

INSERT INTO `seraph_privilege_on_object` (`privilege_id`, `privilage_name`) VALUES
(1, 'Seen'),
(2, 'Download'),
(3, 'Upload On Directory'),
(4, 'Delete');

-- --------------------------------------------------------

--
-- Table structure for table `upload_record`
--

CREATE TABLE `upload_record` (
  `upload_id` varchar(25) NOT NULL,
  `parent` bigint(20) UNSIGNED DEFAULT NULL,
  `benutzer` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_record`
--

INSERT INTO `upload_record` (`upload_id`, `parent`, `benutzer`) VALUES
('2UO4WF4JRALCR3XN23VEZRSUZ', NULL, 1),
('A6SJ0VORWW9RPBX5HS48EMYP5', NULL, NULL),
('AX4WBKZTKVMZE9UID4Z4JEXWU', NULL, NULL),
('BK8FCWMA9YLEFPW8E0Z9UJV6Q', NULL, NULL),
('EYE2ZNMNPV0OJ8CYNK814KGPC', NULL, 1),
('G7BLFNET118OS4YP7R8HOMGDO', NULL, NULL),
('HLUM6TA4PLYBG11DGV7OQ0Z4O', NULL, NULL),
('KPFWI2URPC2MHIT8X74SUADH6', NULL, NULL),
('LVKTXLCAQA3GZVU6HGOGNRK7L', NULL, NULL),
('M9JZFIRFXKPUN0L2VJINKWBSJ', NULL, 1),
('OCKJN4YTI0BPMG3EM82B7VHTI', NULL, NULL),
('X1C3XWKT9IG7NGQXU1TX56RV3', NULL, NULL),
('Z07W6YLRPN3DABM9ADN9V7P5T', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `upload_record_files`
--

CREATE TABLE `upload_record_files` (
  `file_id` bigint(20) UNSIGNED NOT NULL,
  `upload_id` varchar(25) NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_directory` tinyint(1) NOT NULL DEFAULT '0',
  `size` bigint(20) UNSIGNED NOT NULL,
  `parent` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_record_files`
--

INSERT INTO `upload_record_files` (`file_id`, `upload_id`, `name`, `is_directory`, `size`, `parent`) VALUES
(276097542088009080, 'A6SJ0VORWW9RPBX5HS48EMYP5', 'abc', 0, 206768, NULL),
(1185050471103644676, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'IDE', 1, 0, NULL),
(1442882519419434883, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'Activation Code.txt', 0, 12179, 5734725228537982277),
(2696504614817558093, 'LVKTXLCAQA3GZVU6HGOGNRK7L', 'Fanny.rar', 0, 1735171, NULL),
(2772926719218079277, 'AX4WBKZTKVMZE9UID4Z4JEXWU', 'abc', 0, 206768, NULL),
(3415204860629231832, 'X1C3XWKT9IG7NGQXU1TX56RV3', 'Fanny.rar', 0, 1735171, NULL),
(3603966326049647745, 'OCKJN4YTI0BPMG3EM82B7VHTI', 'Seraph.exe', 0, 1289216, NULL),
(3821535791474664178, 'KPFWI2URPC2MHIT8X74SUADH6', 'test(1)', 0, 1169, NULL),
(5734725228537982277, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'Patch Serial', 1, 0, 6714218464482049457),
(6081039842588743449, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'JetBrains PhpStorm PHP v10.0 Build 143.381   Activation Code - softasm.com', 1, 0, 1185050471103644676),
(6141439967102654865, 'BK8FCWMA9YLEFPW8E0Z9UJV6Q', 'Fanny.rar', 0, 1735171, NULL),
(6233131185413531622, 'EYE2ZNMNPV0OJ8CYNK814KGPC', 'Fanny.rar', 0, 1735171, NULL),
(6714218464482049457, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'JetBrains PhpStorm PHP v10.0 Build 143.381   Activation Code - softasm.com', 1, 0, 6081039842588743449),
(7499566135417837034, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'Download Free Software Full Version - All Categories.URL', 0, 118, 6714218464482049457),
(7857449840813478001, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'How To Install.txt', 0, 603, 6714218464482049457),
(8293870524226172623, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'Patch.exe', 0, 405504, 5734725228537982277),
(8579012885900243434, '2UO4WF4JRALCR3XN23VEZRSUZ', 'pertama', 0, 0, NULL),
(8757229800688516367, 'M9JZFIRFXKPUN0L2VJINKWBSJ', 'db.sql', 0, 85165129, NULL),
(8802149144122790696, 'G7BLFNET118OS4YP7R8HOMGDO', 'Fanny.rar', 0, 1735171, NULL),
(8958522176992705075, 'HLUM6TA4PLYBG11DGV7OQ0Z4O', 'Setup.exe', 0, 161960752, 6714218464482049457),
(9171089599085599748, 'Z07W6YLRPN3DABM9ADN9V7P5T', 'db.sql', 0, 85165129, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_list_winapi`
--
ALTER TABLE `app_list_winapi`
  ADD PRIMARY KEY (`app_id`),
  ADD KEY `owner` (`owner`);

--
-- Indexes for table `benutzer`
--
ALTER TABLE `benutzer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `download_record`
--
ALTER TABLE `download_record`
  ADD PRIMARY KEY (`id`),
  ADD KEY `downloader` (`benutzer`);

--
-- Indexes for table `download_record_files`
--
ALTER TABLE `download_record_files`
  ADD KEY `download_id` (`download_id`),
  ADD KEY `file_id` (`file_id`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id`),
  ADD KEY `owner` (`owner`),
  ADD KEY `parent` (`parent`);

--
-- Indexes for table `file_change_recorder`
--
ALTER TABLE `file_change_recorder`
  ADD KEY `id_dir` (`id_dir`),
  ADD KEY `owner` (`owner`);

--
-- Indexes for table `file_operation_log`
--
ALTER TABLE `file_operation_log`
  ADD PRIMARY KEY (`id_operation`),
  ADD KEY `id_file` (`id_dir`);

--
-- Indexes for table `file_operation_update_log`
--
ALTER TABLE `file_operation_update_log`
  ADD PRIMARY KEY (`id_operation`),
  ADD KEY `format` (`format`),
  ADD KEY `owner` (`owner`);

--
-- Indexes for table `login_log_winapi`
--
ALTER TABLE `login_log_winapi`
  ADD PRIMARY KEY (`login_id`),
  ADD KEY `benutzer` (`benutzer`),
  ADD KEY `app` (`app`);

--
-- Indexes for table `login_log_winapi_fail`
--
ALTER TABLE `login_log_winapi_fail`
  ADD KEY `benutzer` (`benutzer`),
  ADD KEY `app` (`app`);

--
-- Indexes for table `privilege_benutzer`
--
ALTER TABLE `privilege_benutzer`
  ADD PRIMARY KEY (`benutzer`,`privilege_id`),
  ADD KEY `privilege_id` (`privilege_id`);

--
-- Indexes for table `privilege_benutzer_on_object`
--
ALTER TABLE `privilege_benutzer_on_object`
  ADD PRIMARY KEY (`benutzer`,`file_id`,`privilege_id`),
  ADD KEY `file_id` (`file_id`),
  ADD KEY `privilege_id` (`privilege_id`);

--
-- Indexes for table `privilege_group`
--
ALTER TABLE `privilege_group`
  ADD PRIMARY KEY (`privilege_group_id`);

--
-- Indexes for table `privilege_group_member`
--
ALTER TABLE `privilege_group_member`
  ADD PRIMARY KEY (`group_id`,`benutzer`),
  ADD KEY `benutzer` (`benutzer`);

--
-- Indexes for table `privilege_group_privilege`
--
ALTER TABLE `privilege_group_privilege`
  ADD PRIMARY KEY (`privilege_group_id`,`privilege_id`),
  ADD KEY `privilege_id` (`privilege_id`);

--
-- Indexes for table `recyle_bin`
--
ALTER TABLE `recyle_bin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `file_owner` (`file_owner`),
  ADD KEY `parent` (`parent`),
  ADD KEY `parent_undeleted` (`parent_undeleted`);

--
-- Indexes for table `seraph_privilege`
--
ALTER TABLE `seraph_privilege`
  ADD PRIMARY KEY (`privilege_id`);

--
-- Indexes for table `seraph_privilege_on_object`
--
ALTER TABLE `seraph_privilege_on_object`
  ADD PRIMARY KEY (`privilege_id`);

--
-- Indexes for table `upload_record`
--
ALTER TABLE `upload_record`
  ADD PRIMARY KEY (`upload_id`),
  ADD KEY `parent` (`parent`),
  ADD KEY `benutzer` (`benutzer`);

--
-- Indexes for table `upload_record_files`
--
ALTER TABLE `upload_record_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `upload_id` (`upload_id`),
  ADD KEY `parent` (`parent`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_list_winapi`
--
ALTER TABLE `app_list_winapi`
  MODIFY `app_id` bigint(20) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `seraph_privilege`
--
ALTER TABLE `seraph_privilege`
  MODIFY `privilege_id` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `app_list_winapi`
--
ALTER TABLE `app_list_winapi`
  ADD CONSTRAINT `app_list_winapi_ibfk_1` FOREIGN KEY (`owner`) REFERENCES `benutzer` (`id`);

--
-- Constraints for table `download_record`
--
ALTER TABLE `download_record`
  ADD CONSTRAINT `download_record_ibfk_2` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`);

--
-- Constraints for table `download_record_files`
--
ALTER TABLE `download_record_files`
  ADD CONSTRAINT `download_record_files_ibfk_1` FOREIGN KEY (`download_id`) REFERENCES `download_record` (`id`),
  ADD CONSTRAINT `download_record_files_ibfk_2` FOREIGN KEY (`file_id`) REFERENCES `file` (`id`);

--
-- Constraints for table `file`
--
ALTER TABLE `file`
  ADD CONSTRAINT `file_ibfk_2` FOREIGN KEY (`owner`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `file_ibfk_3` FOREIGN KEY (`parent`) REFERENCES `file` (`id`);

--
-- Constraints for table `file_operation_update_log`
--
ALTER TABLE `file_operation_update_log`
  ADD CONSTRAINT `file_operation_update_log_ibfk_3` FOREIGN KEY (`owner`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `file_operation_update_log_ibfk_4` FOREIGN KEY (`id_operation`) REFERENCES `file_operation_log` (`id_operation`);

--
-- Constraints for table `login_log_winapi`
--
ALTER TABLE `login_log_winapi`
  ADD CONSTRAINT `login_log_winapi_ibfk_1` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `login_log_winapi_ibfk_2` FOREIGN KEY (`app`) REFERENCES `app_list_winapi` (`app_id`);

--
-- Constraints for table `login_log_winapi_fail`
--
ALTER TABLE `login_log_winapi_fail`
  ADD CONSTRAINT `login_log_winapi_fail_ibfk_1` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `login_log_winapi_fail_ibfk_2` FOREIGN KEY (`app`) REFERENCES `app_list_winapi` (`app_id`);

--
-- Constraints for table `privilege_benutzer`
--
ALTER TABLE `privilege_benutzer`
  ADD CONSTRAINT `privilege_benutzer_ibfk_1` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `privilege_benutzer_ibfk_2` FOREIGN KEY (`privilege_id`) REFERENCES `seraph_privilege` (`privilege_id`);

--
-- Constraints for table `privilege_benutzer_on_object`
--
ALTER TABLE `privilege_benutzer_on_object`
  ADD CONSTRAINT `privilege_benutzer_on_object_ibfk_1` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `privilege_benutzer_on_object_ibfk_2` FOREIGN KEY (`file_id`) REFERENCES `file` (`id`),
  ADD CONSTRAINT `privilege_benutzer_on_object_ibfk_3` FOREIGN KEY (`privilege_id`) REFERENCES `seraph_privilege_on_object` (`privilege_id`);

--
-- Constraints for table `privilege_group_member`
--
ALTER TABLE `privilege_group_member`
  ADD CONSTRAINT `privilege_group_member_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `privilege_group` (`privilege_group_id`),
  ADD CONSTRAINT `privilege_group_member_ibfk_2` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `privilege_group_member_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `privilege_group` (`privilege_group_id`),
  ADD CONSTRAINT `privilege_group_member_ibfk_4` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`);

--
-- Constraints for table `privilege_group_privilege`
--
ALTER TABLE `privilege_group_privilege`
  ADD CONSTRAINT `privilege_group_privilege_ibfk_1` FOREIGN KEY (`privilege_group_id`) REFERENCES `privilege_group` (`privilege_group_id`),
  ADD CONSTRAINT `privilege_group_privilege_ibfk_2` FOREIGN KEY (`privilege_id`) REFERENCES `seraph_privilege` (`privilege_id`);

--
-- Constraints for table `recyle_bin`
--
ALTER TABLE `recyle_bin`
  ADD CONSTRAINT `recyle_bin_ibfk_2` FOREIGN KEY (`file_owner`) REFERENCES `benutzer` (`id`),
  ADD CONSTRAINT `recyle_bin_ibfk_3` FOREIGN KEY (`parent`) REFERENCES `recyle_bin` (`id`),
  ADD CONSTRAINT `recyle_bin_ibfk_4` FOREIGN KEY (`parent_undeleted`) REFERENCES `file` (`id`);

--
-- Constraints for table `upload_record`
--
ALTER TABLE `upload_record`
  ADD CONSTRAINT `upload_record_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `file` (`id`),
  ADD CONSTRAINT `upload_record_ibfk_2` FOREIGN KEY (`benutzer`) REFERENCES `benutzer` (`id`);

--
-- Constraints for table `upload_record_files`
--
ALTER TABLE `upload_record_files`
  ADD CONSTRAINT `upload_record_files_ibfk_1` FOREIGN KEY (`upload_id`) REFERENCES `upload_record` (`upload_id`),
  ADD CONSTRAINT `upload_record_files_ibfk_3` FOREIGN KEY (`parent`) REFERENCES `upload_record_files` (`file_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
